package com.bioreactordt.modelsservice.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExperimentationState {

    private String experimentId;
    private double ph;
    private double temperature;
    private double population;
    private double mu;
    private double gammaPh;
    private double gammaTemp;
    private String growthStatus;
}
