package com.bioreactordt.strainservice.services;

import com.bioreactordt.strainservice.models.InitialStrain;
import com.bioreactordt.strainservice.models.StrainFamily;
import greycat.GreyCat;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@Slf4j
public class StrainService {

    private final String greycatUrl;
    private GreyCat greycat;




    public StrainService(@Value("${greycat.url}") String greycatUrl) {
        this.greycatUrl = greycatUrl;
    }

    private synchronized GreyCat greycat() {
        if (greycat == null) {
            try {
                greycat = new GreyCat(greycatUrl, null, false, false);
                log.info("Connected to GreyCat at {}", greycatUrl);
            } catch (Exception e) {
                log.error("Failed to connect to GreyCat at {}: {}", greycatUrl, e.getMessage());
                throw new RuntimeException("Failed to connect to GreyCat at " + greycatUrl, e);
            }
        }
        return greycat;
    }





    public void saveFamily(StrainFamily f) {
        try{
            greycat().call("project::family_save", f.getStrainId(), f.getName(), f.getMuMax(), f.getLatency(), f.getPhMin(), f.getPhOpt(), f.getPhMax(), f.getTempMin(), f.getTempOpt(), f.getTempMax());
            log.info("Strain Family {} registered", f.getStrainId());

        }catch (Exception e) {
            log.error("Failed to save a family: {}", e.getMessage());
        }
    }


    public void saveInitialStrain(InitialStrain initial) {
        try {
            log.info("Received initial strain: condId={}, familyIds={}", initial.getCondId(), initial.getFamilyIds());

            String familyId = initial.getFamilyIds().get(0);
            log.info("using familyid {}", familyId);

            greycat().call("project::save_initial_strain", initial.getCondId(), initial.getPopulationInit(), initial.getPopulationMax(), familyId);

        } catch (Exception e) {
            log.error("failed to link cond init to strain {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public InitialStrain getInitialStrain(String condId) throws IOException {
        Object raw = greycat().call("project::get_initial_strain", condId);

        String str = raw.toString()
                .replace("core::Array[", "")
                .replace("]", "");

        String[] parts = str.split(",");
       // log.info(parts[0]);
        return new InitialStrain(
                parts[0],
                Double.parseDouble(parts[1]),
                Double.parseDouble(parts[2]),
                List.of(parts[3])
        );
    }


    public List<StrainFamily> getAllFamilies() {
        try {
            Object raw = greycat().call("project::get_all_families");
            if (raw == null) return List.of();

            // raw.toString() looks like: core::Array[core::Array[FAM-001,E.coli,0.5,...],core::Array[FAM-002,...]]
            String full = raw.toString()
                    .replaceFirst("^core::Array\\[", "")
                    .replaceAll("\\]$", "");

            String[] entries = full.split("\\],core::Array\\[");

            List<StrainFamily> families = new java.util.ArrayList<>();
            for (String entry : entries) {
                String clean = entry.replace("core::Array[", "").replace("]", "");
                String[] parts = clean.split(",");
                if (parts.length < 10) continue;

                StrainFamily f = new StrainFamily();
                f.setStrainId(parts[0]);
                f.setName(parts[1]);
                f.setMuMax(Double.parseDouble(parts[2]));
                f.setLatency(Double.parseDouble(parts[3]));
                f.setPhMin(Double.parseDouble(parts[4]));
                f.setPhOpt(Double.parseDouble(parts[5]));
                f.setPhMax(Double.parseDouble(parts[6]));
                f.setTempMin(Double.parseDouble(parts[7]));
                f.setTempOpt(Double.parseDouble(parts[8]));
                f.setTempMax(Double.parseDouble(parts[9]));
                families.add(f);
            }
            return families;

        } catch (Exception e) {
            log.error("Failed to get all families: {}", e.getMessage());
            return List.of();
        }
    }

    public List<InitialStrain> getAllInitConds() {
        try {
            Object raw = greycat().call("project::get_all_init_conds");
            if (raw == null) return List.of();

            String full = raw.toString()
                    .replaceFirst("^core::Array\\[", "")
                    .replaceAll("\\]$", "");

            String[] entries = full.split("\\],core::Array\\[");

            List<InitialStrain> strains = new java.util.ArrayList<>();
            for (String entry : entries) {
                String clean = entry.replace("core::Array[", "").replace("]", "");
                String[] parts = clean.split(",");
                if (parts.length < 4) continue;

                strains.add(new InitialStrain(
                        parts[0],
                        Double.parseDouble(parts[1]),
                        Double.parseDouble(parts[2]),
                        List.of(parts[3])
                ));
            }
            return strains;

        } catch (Exception e) {
            log.error("Failed to get all init conds: {}", e.getMessage());
            return List.of();
        }
    }




}
































// raw.toString() = "core::Array[COND-001,1000000.0,1.0E10,FAM-001]"
