package com.bioreactordt.experimentservice.services;


import com.bioreactordt.experimentservice.models.Experimentation;
import com.bioreactordt.experimentservice.models.ExperimentationState;
import com.fasterxml.jackson.databind.ObjectMapper;
import greycat.GreyCat;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ExperimentService {

    private final String greycatUrl;
    private GreyCat greycat;

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;



    public ExperimentService(@Value("${greycat.url}") String greycatUrl,  KafkaTemplate<String, String> kafkaTemplate, ObjectMapper objectMapper) {
        this.greycatUrl = greycatUrl;
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }


    private synchronized GreyCat greycat() {
        if (greycat == null) {
            try {
                greycat = new GreyCat(greycatUrl, null, false, false);
                log.info("Connected to GreyCat at {}", greycatUrl);
            } catch (Exception e) {
                log.error("Failed to connect to GreyCat at {}: {}", greycatUrl, e.getMessage());
                throw new RuntimeException("Failed to connect to GreyCat at " + greycatUrl, e);
            }
        }
        return greycat;
    }



    public void createExperiment(Experimentation ex) {
        try {
            greycat().call("project::experiment_save", ex.getExperimentId(), ex.getReactorId(), ex.getCondInit(), ex.getPopulationModel(), ex.getPhModel(), ex.getTempModel(), ex.getSource());
            log.info("Experiment created");

            kafkaTemplate.send("experiment-started", objectMapper.writeValueAsString(ex)); //send to  model service

        } catch (Exception e) {
            log.error("Failed to save experiment {}: {}", ex, e.getMessage());
        }
    }

    public void createExperimentState( ExperimentationState s) {
        try {
            greycat().call("project::experiment_state_save", s.getExperimentId(), s.getPh(), s.getTemperature(), s.getPopulation(), s.getMu(), s.getGammaPh(), s.getGammaTemp(), s.getGrowthStatus());

            log.info("Experiment state created");

        } catch (Exception e) {
            log.error("Failed to push experiment state to GreyCat: {}", e.getMessage());
        }
    }


    public Map<String, Object> getExperimentWithStates(String experimentId) {
        try {
            Object raw = greycat().call("project::get_experiment_with_states", experimentId);
            if (raw == null) return null;

            String str = raw.toString()
                    .replace("core::Array[", "")
                    .replace("]", "");

            String[] parts = str.split(",");

            Map<String, Object> result = new LinkedHashMap<>();
            result.put("experimentId",    parts[0].trim());
            result.put("reactorId",       parts[1].trim());
            result.put("populationModel", parts[2].trim());
            result.put("phModel",         parts[3].trim());
            result.put("tempModel",       parts[4].trim());
            result.put("source",          parts[5].trim().toLowerCase());

            List<Map<String, Object>> states = new ArrayList<>();
            for (int i = 6; i + 7 < parts.length; i += 8) {
                Map<String, Object> state = new LinkedHashMap<>();
                state.put("timestamp",    parts[i].trim());
                state.put("ph",           Double.parseDouble(parts[i+1].trim()));
                state.put("temperature",  Double.parseDouble(parts[i+2].trim()));
                state.put("population",   Double.parseDouble(parts[i+3].trim()));
                state.put("mu",           Double.parseDouble(parts[i+4].trim()));
                state.put("gammaPh",      Double.parseDouble(parts[i+5].trim()));
                state.put("gammaTemp",    Double.parseDouble(parts[i+6].trim()));
                state.put("growthStatus", parts[i+7].trim());
                states.add(state);
            }
            result.put("states", states);

            return result;

        } catch (Exception e) {
            log.error("Failed to get experiment {}: {}", experimentId, e.getMessage());
            return null;
        }
    }


    public List<Map<String, Object>> getAllExperiments() {
        try {
            Object raw = greycat().call("project::get_all_experiments");
            if (raw == null) return List.of();

            String full = raw.toString()
                    .replaceFirst("^core::Array\\[", "")
                    .replaceAll("\\]$", "");

            String[] entries = full.split("\\],core::Array\\[");

            List<Map<String, Object>> results = new ArrayList<>();
            for (String entry : entries) {
                String clean = entry.replace("core::Array[", "").replace("]", "");
                String[] parts = clean.split(",");
                if (parts.length < 6) continue;
                Map<String, Object> exp = new LinkedHashMap<>();
                exp.put("experimentId",    parts[0].trim());
                exp.put("reactorId",       parts[1].trim());
                exp.put("populationModel", parts[2].trim());
                exp.put("phModel",         parts[3].trim());
                exp.put("tempModel",       parts[4].trim());
                exp.put("source",          parts[5].trim().toLowerCase());
                results.add(exp);
            }
            return results;
        } catch (Exception e) {
            log.error("Failed to get all experiments: {}", e.getMessage());
            return List.of();
        }
    }
}
