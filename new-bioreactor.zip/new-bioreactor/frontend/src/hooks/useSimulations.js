import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { SIM, EXP, defaultSimStep } from '../helpers/constants';

const defaultForm = () => ({
    reactorId: 'BIOREACTOR-001',
    condInit: '',
    totalScreenMin: 2,
    ticksPerStep: 10,
    populationModel: 'logistic',
    phModel: 'cardinal',
    tempModel: 'cardinal',
});

const emptySimTwin = {
    mu: undefined, population: 0,
    gammaPh: 0, gammaTemp: 0,
    growthStatus: '—', ph: 0, temperature: 0,
};

export function useSimulations() {
    const [form,        setForm]        = useState(defaultForm());
    const [steps,       setSteps]       = useState([defaultSimStep()]);
    const [launching,   setLaunching]   = useState(false);
    const [flash,       setFlash]       = useState(null);
    const [lastSimId,   setLastSimId]   = useState(null);

    // Isolated sim twin state — never shared with physical twin
    const [simRunning,  setSimRunning]  = useState(false);
    const [simTwin,     setSimTwin]     = useState(emptySimTwin);
    const pollRef    = useRef(null);
    const emptyCount = useRef(0);
    const MAX_EMPTY  = 5;

    const showFlash = (msg, ok = true) => {
        setFlash({ msg, ok });
        setTimeout(() => setFlash(null), 4000);
    };

    const addStep    = ()        => setSteps(p => [...p, defaultSimStep()]);
    const removeStep = i         => setSteps(p => p.filter((_, idx) => idx !== i));
    const updateStep = (i, f, v) => setSteps(p => p.map((s, idx) => idx === i ? { ...s, [f]: v } : s));

    const fetchSimState = async (experimentId) => {
        if (!experimentId) return;
        try {
            const r = await axios.get(`${EXP}/${experimentId}`);
            const states = r.data?.states;
            if (Array.isArray(states) && states.length > 0) {
                emptyCount.current = 0;
                setSimTwin(states[states.length - 1]);
            } else {
                emptyCount.current += 1;
                if (emptyCount.current >= MAX_EMPTY) {
                    stopSimPoll();
                    setSimRunning(false);
                }
            }
        } catch (_) {
            emptyCount.current += 1;
            if (emptyCount.current >= MAX_EMPTY) {
                stopSimPoll();
                setSimRunning(false);
            }
        }
    };

    const startSimPoll = (experimentId) => {
        stopSimPoll();
        setSimRunning(true);
        setSimTwin(emptySimTwin);
        emptyCount.current = 0;
        fetchSimState(experimentId);
        pollRef.current = setInterval(() => fetchSimState(experimentId), 1000);
    };

    const stopSimPoll = () => {
        if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null; }
    };

    useEffect(() => () => stopSimPoll(), []);

    const launchSim = async (onLaunched) => {
        if (!form.condInit.trim()) { showFlash('condInit is required', false); return; }
        setLaunching(true);
        // Reset sim display before launching so physical twin is unaffected
        setSimRunning(false);
        setSimTwin(emptySimTwin);
        try {
            const res = await axios.post(`${SIM}/start`, {
                ...form,
                steps: steps.map(s => ({
                    ph: s.ph,
                    temperature: s.temperature,
                    realDurationMin: s.realDurationMin,
                })),
            });

            const text = typeof res.data === 'string' ? res.data : '';
            const match = text.match(/Simulation started with (.+)/);
            const expId = match ? match[1].trim() : null;

            if (expId) {
                setLastSimId(expId);
                showFlash(`Simulation started! ID: ${expId.slice(0, 8)}…`);
                startSimPoll(expId);
                if (onLaunched) onLaunched({
                    experimentId: expId,
                    source: 'sim',
                    reactorId: form.reactorId,
                    condInit: form.condInit,
                    populationModel: form.populationModel,
                    phModel: form.phModel,
                    tempModel: form.tempModel,
                });
            } else {
                showFlash('Simulation started!');
                if (onLaunched) onLaunched(null);
            }
        } catch (err) {
            showFlash('Failed to launch simulation — check that the digital-twin service is running', false);
        } finally {
            setLaunching(false);
        }
    };

    return {
        form, setForm,
        steps, addStep, removeStep, updateStep,
        launching, flash,
        launchSim,
        lastSimId,
        simRunning,
        simTwin,
    };
}