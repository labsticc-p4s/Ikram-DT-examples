import React, { useState } from 'react';
import { PH_MODELS, TEMP_MODELS, POP_MODELS, defaultSimStep, fmt2, fmt4, fmtPop, statusClass, badge } from '../helpers/constants';
import GammaBar from './GammaBar';

function toMin(value, unit) {
    if (unit === 's') return value / 60;
    if (unit === 'h') return value * 60;
    return value;
}

function fromMin(valueMin, unit) {
    if (unit === 's') return Math.round(valueMin * 60);
    if (unit === 'h') return +(valueMin / 60).toFixed(2);
    return valueMin;
}

function DurationInput({ label, valueMin, onChange }) {
    const [unit, setUnit] = useState('min');

    return (
        <div className="step-field">
            <div className="time-row-label">{label}</div>
            <div className="time-input-row">
                <input
                    type="number" min="0.1" step="any"
                    value={fromMin(valueMin, unit)}
                    onChange={e => onChange(toMin(+e.target.value, unit))}
                />
                <select value={unit} onChange={e => setUnit(e.target.value)}>
                    <option value="s">seconds</option>
                    <option value="min">minutes</option>
                    <option value="h">hours</option>
                </select>
            </div>
        </div>
    );
}

function StepRow({ step, index, total, onChange, onRemove }) {
    const sl = (field, min, max, step_, label, unit = '') => (
        <div className="step-field">
            <label>{label}: <strong>{step[field]}{unit}</strong></label>
            <input
                type="range" min={min} max={max} step={step_} value={step[field]}
                onChange={e => onChange(field, +e.target.value)}
            />
        </div>
    );

    return (
        <div className="step-card">
            <div className="step-header">
                <span>Step {index + 1} / {total}</span>
                {total > 1 && <button className="btn-remove" onClick={onRemove}>✕</button>}
            </div>
            {sl('ph', 4,  10,  0.1, 'pH')}
            {sl('temperature', 15, 55,  0.5, 'Temperature', ' °C')}
            <DurationInput
                label="Step real duration"
                valueMin={step.realDurationMin}
                onChange={v => onChange('realDurationMin', v)}
            />
        </div>
    );
}

export default function SimulationsCard({
    form, setForm,
    steps, addStep, removeStep, updateStep,
    launching, flash,
    launchSim,
    lastSimId,
    initials,
    simRunning,
    simTwin,
}) {
    const hasSim = simTwin && simTwin.mu !== undefined;
    const sc = hasSim ? statusClass(simTwin.growthStatus) : '';

    const sel = (field, opts, label) => (
        <div className="step-field">
            <label>{label}</label>
            <select value={form[field]} onChange={e => setForm(p => ({ ...p, [field]: e.target.value }))}>
                {opts.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
        </div>
    );

    return (
        <div className="card">
            <h2>
                Simulation
                {simRunning && <span className="twin-live-pill" style={{ background: '#7c3aed' }}>RUNNING</span>}
            </h2>

            {flash && (
                <div className={`strain-flash ${flash.ok ? 'ok' : 'err'}`}>{flash.msg}</div>
            )}

            {lastSimId && (
                <div className="sim-id-box">
                    <span className="sim-id-label">Last Experiment ID</span>
                    <span className="sim-id-value" title={lastSimId}>{lastSimId}</span>
                </div>
            )}

            {/* Sim live metrics — isolated from physical twin */}
            {simRunning && (
                <div className="env-section" style={{ marginBottom: 8 }}>
                    <div className="env-title" style={{ color: '#7c3aed' }}>Live Sim State</div>
                    <div className={`reactor-circle ${sc}`} style={{ marginTop: 4, marginBottom: 6 }}>
                        <span className="reactor-label">
                            {hasSim ? (simTwin.growthStatus || '—') : '…'}
                        </span>
                    </div>
                    {hasSim ? (
                        <>
                            <div className="twin-metrics-grid">
                                <div className="twin-metric">
                                    <span className="twin-metric-val">{fmt4(simTwin.mu)}</span>
                                    <span className="twin-metric-lbl">µ (/h)</span>
                                </div>
                                <div className="twin-metric">
                                    <span className="twin-metric-val green">{fmtPop(simTwin.population)}</span>
                                    <span className="twin-metric-lbl">Bact/mL</span>
                                </div>
                                <div className="twin-metric">
                                    <span className="twin-metric-val">{fmt2(simTwin.ph)}</span>
                                    <span className="twin-metric-lbl">pH</span>
                                </div>
                                <div className="twin-metric">
                                    <span className="twin-metric-val">{fmt2(simTwin.temperature)}°C</span>
                                    <span className="twin-metric-lbl">Temp</span>
                                </div>
                            </div>
                            <GammaBar label="γ pH"   value={simTwin.gammaPh}   />
                            <GammaBar label="γ Temp" value={simTwin.gammaTemp} />
                            <div className="info-row"><span>Status</span>{badge(simTwin.growthStatus)}</div>
                        </>
                    ) : (
                        <p className="empty-note" style={{ margin: '4px 0' }}>Waiting for first state…</p>
                    )}
                </div>
            )}

            <div className="env-section">
                <div className="env-title">Configuration</div>

                <div className="step-field">
                    <label>Reactor ID</label>
                    <input
                        type="text"
                        value={form.reactorId}
                        onChange={e => setForm(p => ({ ...p, reactorId: e.target.value }))}
                        placeholder="Bioreactor id..."
                    />
                </div>

                <div className="step-field">
                    <label>condInit</label>
                    {initials && initials.length > 0 ? (
                        <select value={form.condInit} onChange={e => setForm(p => ({ ...p, condInit: e.target.value }))}>
                            <option value="">— select —</option>
                            {initials.map(c => (
                                <option key={c.condId} value={c.condId}>{c.condId}</option>
                            ))}
                        </select>
                    ) : (
                        <input
                            type="text"
                            placeholder="Condition initial for strain..."
                            value={form.condInit}
                            onChange={e => setForm(p => ({ ...p, condInit: e.target.value }))}
                        />
                    )}
                </div>

                <DurationInput
                    label="Simulation screen duration"
                    valueMin={form.totalScreenMin}
                    onChange={v => setForm(p => ({ ...p, totalScreenMin: v }))}
                />

                <div className="step-field">
                    <label>Ticks / step: <strong>{form.ticksPerStep}</strong></label>
                    <input
                        type="range" min={1} max={50} step={1} value={form.ticksPerStep}
                        onChange={e => setForm(p => ({ ...p, ticksPerStep: +e.target.value }))}
                    />
                </div>

                {sel('populationModel', POP_MODELS, 'Population model')}
                {sel('phModel',         PH_MODELS,  'pH model')}
                {sel('tempModel',       TEMP_MODELS, 'Temp model')}
            </div>

            <div className="env-section">
                <div className="env-title" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <span>Steps</span>
                    <button className="btn blue small" onClick={addStep}>+ Add Step</button>
                </div>

                {steps.map((s, i) => (
                    <StepRow
                        key={i} step={s} index={i} total={steps.length}
                        onChange={(f, v) => updateStep(i, f, v)}
                        onRemove={() => removeStep(i)}
                    />
                ))}
            </div>

            <button className="btn green full-width" onClick={launchSim} disabled={launching}>
                {launching ? 'Launching…' : 'Launch Simulation'}
            </button>
        </div>
    );
}