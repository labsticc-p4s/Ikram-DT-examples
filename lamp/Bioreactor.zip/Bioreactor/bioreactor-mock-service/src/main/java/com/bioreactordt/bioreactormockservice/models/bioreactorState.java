package com.bioreactordt.bioreactormockservice.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class bioreactorState {

    // facteurs environnementaux
    private String reactorId;

    private double ph;
    private double temperature;

    private double hours;


}
