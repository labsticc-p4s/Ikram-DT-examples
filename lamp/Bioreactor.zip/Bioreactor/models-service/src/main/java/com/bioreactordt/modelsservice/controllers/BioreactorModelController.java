package com.bioreactordt.modelsservice.controllers;

import com.bioreactordt.modelsservice.manager.ModelCoordinator;
import com.bioreactordt.modelsservice.models.ModelSelection;
import com.bioreactordt.modelsservice.models.StrainConfig;
import com.bioreactordt.modelsservice.services.BioreactorModelService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/models")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class BioreactorModelController {

    private final ModelCoordinator coordinator;

    // what models are available
    @GetMapping("/available")
    public ResponseEntity<Map<String, List<String>>> available() {
        return ResponseEntity.ok(Map.of(
                "ph",          coordinator.availablePhModels(),
                "temperature", coordinator.availableTempModels(),
                "population",  coordinator.availablePopModels()
        ));
    }

    // get current selection for a reactor
    @GetMapping("/{reactorId}")
    public ResponseEntity<ModelSelection> getSelection(@PathVariable String reactorId) {
        return ResponseEntity.ok(coordinator.getSelection(reactorId));
    }

    // user picks models for a reactor
    @PostMapping("/select")
    public ResponseEntity<ModelSelection> select(@RequestBody ModelSelection selection) {
        coordinator.select(selection);
        return ResponseEntity.ok(selection);

    }

    // reset to defaults
    @DeleteMapping("/{reactorId}")
    public ResponseEntity<Map<String, String>> reset(@PathVariable String reactorId) {
        coordinator.reset(reactorId);
        return ResponseEntity.ok(Map.of("reset", reactorId));
    }
}