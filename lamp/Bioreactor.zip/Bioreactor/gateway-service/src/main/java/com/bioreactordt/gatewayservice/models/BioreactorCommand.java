package com.bioreactordt.gatewayservice.models;

import lombok.*;



@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BioreactorCommand { //cmd from twin to physical

    private String field;   //ph, temp or speed
    private double value;
}
