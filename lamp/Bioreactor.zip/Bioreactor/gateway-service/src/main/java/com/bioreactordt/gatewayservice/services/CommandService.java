package com.bioreactordt.gatewayservice.services;

import com.bioreactordt.gatewayservice.models.BioreactorCommand;
import com.bioreactordt.gatewayservice.models.BioreactorState;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class CommandService {

    private final RestTemplate restTemplate;

    @Value("${services.physical-url}")
    private String physicalUrl;

    public boolean sendCmds(BioreactorCommand cmd) {
        try {
            restTemplate.postForObject(
                    physicalUrl + "/api/physical/reactor/twin-command",
                    Map.of(cmd.getField(), cmd.getValue()),
                    String.class);
            log.info("Command forwarded: {}={}", cmd.getField(), cmd.getValue());
            return true;
        } catch (Exception e) {
            log.error("Failed to forward command {}={}: {}", cmd.getField(), cmd.getValue(), e.getMessage());
            return false;
        }
    }

}
