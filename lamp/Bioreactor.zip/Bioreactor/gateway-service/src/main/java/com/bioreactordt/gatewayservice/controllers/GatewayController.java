package com.bioreactordt.gatewayservice.controllers;

import com.bioreactordt.gatewayservice.models.BioreactorCommand;
import com.bioreactordt.gatewayservice.services.*;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/gateway")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class GatewayController {

    private final CommandService commandService;
    private final EnrichedStateService     enrichedService;

    // twin service calls this to send a command to physical bioreactor twinning operation
    @PostMapping("/command")
    public ResponseEntity<Map<String, Object>> command(@RequestBody BioreactorCommand cmd) {
        boolean ok = commandService.sendCmds(cmd);
        return ResponseEntity.ok(Map.of("sent", ok, "field", cmd.getField(), "value", cmd.getValue()));
    }

    @PostMapping("/cache/invalidate/{reactorId}")
    public ResponseEntity<Map<String, String>> invalidate(@PathVariable String reactorId) {
        enrichedService.invalidateCache(reactorId);
        return ResponseEntity.ok(Map.of("invalidated", reactorId));
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of("status", "UP"));
    }
}
